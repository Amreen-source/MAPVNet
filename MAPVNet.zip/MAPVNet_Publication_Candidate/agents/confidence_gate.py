import cv2
import numpy as np
from PIL import Image

def max_foreground_probability(prob_map):
    return float(np.max(prob_map))

def apply_clahe_rgb(image: Image.Image, clip_limit=2.0):
    arr=np.asarray(image.convert("RGB"))
    lab=cv2.cvtColor(arr,cv2.COLOR_RGB2LAB)
    l,a,b=cv2.split(lab)
    clahe=cv2.createCLAHE(clipLimit=clip_limit,tileGridSize=(8,8))
    l=clahe.apply(l)
    out=cv2.merge([l,a,b])
    return Image.fromarray(cv2.cvtColor(out,cv2.COLOR_LAB2RGB))

def tta_variants(image: Image.Image):
    arr=np.asarray(image)
    return [
        Image.fromarray(arr),
        Image.fromarray(np.fliplr(arr).copy()),
        Image.fromarray(np.flipud(arr).copy()),
        Image.fromarray(np.flipud(np.fliplr(arr)).copy()),
    ]

def confidence_gate(prob_map, threshold=0.70):
    score=max_foreground_probability(prob_map)
    return score >= threshold, score
