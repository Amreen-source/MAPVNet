import torch

@torch.no_grad()
def binary_segmentation_metrics(logits, masks, threshold=0.5, eps=1e-8):
    probs = torch.sigmoid(logits)
    pred = probs > threshold
    true = masks > 0

    dims = tuple(range(1, pred.ndim))
    tp = (pred & true).sum(dims).float()
    fp = (pred & ~true).sum(dims).float()
    fn = (~pred & true).sum(dims).float()
    tn = (~pred & ~true).sum(dims).float()

    iou = tp / (tp + fp + fn + eps)
    f1 = 2 * tp / (2 * tp + fp + fn + eps)
    precision = tp / (tp + fp + eps)
    recall = tp / (tp + fn + eps)
    accuracy = (tp + tn) / (tp + tn + fp + fn + eps)

    return {
        "IoU": iou.mean().item(),
        "F1": f1.mean().item(),
        "Precision": precision.mean().item(),
        "Recall": recall.mean().item(),
        "Accuracy": accuracy.mean().item(),
    }
