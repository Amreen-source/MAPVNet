# Checkpoints

Do not commit large model weights directly to normal Git history.

Publish the final paper checkpoints through GitHub Releases, Git LFS, Hugging Face, or Zenodo.

Required release artifacts:

- `efficientnet_b2_router.pth`
- `segformer_b2_pv08.pth`
- `segformer_b4_pv03.pth`
- `swinunet_pv01.pth`
- `segformer_b4_unified.pth` (ablation baseline)
- PatchCore/Anomalib checkpoint or exported model used for PV01 anomaly assessment

For each file, add:
- stable URL
- SHA256
- training configuration
- associated code commit
