# Release blockers before claiming full paper reproducibility

The uploaded GitHub repository did not contain enough information to reconstruct every reported component exactly.

## Must be resolved

1. **Exact PV01 Swin-UNet implementation**
   - `models/swinunet.py` was missing.
   - Copy the exact source used to train `swinunet_pv01.pth`.

2. **Final dataset manifest**
   - Manuscript sections disagree between 3,610/544 and 3,716/560.
   - Release the exact fixed manifest used to generate the reported final metrics.

3. **Router experiment**
   - Manuscript contains two different router experiments.
   - Retain the code/checkpoint/results corresponding to the final paper claim.

4. **Qwen2.5-VL Agent 1**
   - Uploaded pipeline only performs deterministic filename parsing.
   - Add the exact Qwen orchestration code if the paper claims it was executed.

5. **PatchCore Agent 5**
   - Add exact Anomalib/PatchCore training/inference code and model artifact.

6. **Confidence re-processing**
   - Uploaded pipeline warns on low confidence but does not execute CLAHE/TTA retries.
   - Integrate the exact experimental implementation and validate it.

7. **Checkpoint links**
   - Publish model weights with SHA256 hashes.

8. **Fresh-clone test**
   - Run every README command from a clean clone before release.
