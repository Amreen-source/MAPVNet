# Manuscript ↔ repository synchronization

Current reported specialist metrics:
- PV08 IoU 0.8834
- PV03 IoU 0.9405
- PV01 IoU 0.9394
- Macro IoU 0.9211
- Macro F1 0.9587

Current reported ablation:
- Unified macro IoU 0.8156
- Specialist macro IoU 0.9211
- Delta +0.1055

Do not preserve the older README values 0.8052 / 0.8569 / 0.9020 / 0.8547 in the final repository.

Synchronize:
- dataset counts
- split counts
- PV01 input size
- router experiment
- confidence definition
- Qwen agent behavior
- PatchCore behavior
- runtime claims
