# MAPVNet

**MAPVNet: A Resolution-Aware Multi-Agent Framework for Photovoltaic Panel Detection from Multi-Resolution Remote Sensing Imagery**

MAPVNet is a resolution-aware multi-agent AI framework for photovoltaic (PV) panel segmentation across heterogeneous satellite, aerial, and UAV imagery.

> **Publication-candidate repository.** Before final archival release, verify the exact PV01 Swin-UNet implementation, checkpoint compatibility, final dataset manifest, router experiment, and confidence statistic against the code/checkpoints used for the reported paper results. See `docs/RELEASE_BLOCKERS.md`.

## Authors

- Amreen Batool
- Yong-Woon Kim
- Yung-Cheol Byun

Jeju National University, Republic of Korea.

## Core workflow

1. **Agent 1 — Orchestrator**  
   High-level workflow orchestration. The paper describes Qwen2.5-VL-7B plus deterministic metadata parsing.
2. **Agent 2 — Resolution and context router**  
   Resolution-aware specialist selection plus EfficientNet-B2 scene-context classification.
3. **Agent 3 — Resolution-specific specialists**
   - PV08 satellite, 0.8 m GSD → SegFormer-B2
   - PV03 aerial, 0.3 m GSD → SegFormer-B4
   - PV01 UAV, 0.1 m GSD → Swin-UNet
4. **Confidence gate and re-processing**
   - threshold = 0.70
   - CLAHE + flip-based TTA
   - up to three attempts
5. **Agent 4 — Geospatial processing**
   - GIS-compatible GeoTIFF output
6. **Agent 5 — UAV anomaly assessment**
   - PatchCore/Anomalib for PV01
   - anomaly screening only; not physical defect diagnosis
7. **Agent 6 — Operational reporting**
   - text, JSON, map and raster products

## Reported specialist performance

| Model / Resolution | IoU | F1 | Precision | Recall | Accuracy |
|---|---:|---:|---:|---:|---:|
| SegFormer-B2 — PV08 | 0.8834 | 0.9381 | 0.9126 | 0.9651 | 0.9840 |
| SegFormer-B4 — PV03 | 0.9405 | 0.9693 | 0.9600 | 0.9789 | 0.9828 |
| Swin-UNet — PV01 | 0.9394 | 0.9687 | 0.9765 | 0.9611 | 0.9807 |
| **Macro — MAPVNet** | **0.9211** | **0.9587** | **0.9497** | **0.9684** | **0.9825** |

Reported unified SegFormer-B4 macro IoU: **0.8156**  
Reported specialist macro IoU: **0.9211**  
Absolute improvement: **+0.1055 IoU**

## Dataset

Jiang et al. 2021 multi-resolution photovoltaic dataset:

https://doi.org/10.5281/zenodo.5171712

The current manuscript contains inconsistent total/split counts in different sections. This repository therefore avoids claiming a single final count until the exact released manifest is verified. See `docs/RELEASE_BLOCKERS.md`.

Expected layout:

```text
data/
├── PV08/
│   ├── images/
│   └── masks/
├── PV03/
│   ├── images/
│   └── masks/
├── PV01/
│   ├── images/
│   └── masks/
└── router/
    ├── images/
    └── labels.json
```

## Installation

```bash
conda env create -f environment.yml
conda activate mapvnet
```

or

```bash
pip install -r requirements.txt
```

## Training

```bash
python training/train_router.py
python training/train_specialists.py --resolution PV08
python training/train_specialists.py --resolution PV03
python training/train_specialists.py --resolution PV01
python training/train_unified_baseline.py
```

## Evaluation

```bash
python evaluation/eval_router.py
python evaluation/eval_specialists.py
python evaluation/eval_unified_baseline.py
```

## Single-image inference

```bash
python pipeline.py --image path/to/image.bmp
```

## Checkpoints

Large checkpoints are intentionally excluded from ordinary Git history. Put stable download links and SHA256 hashes in `checkpoints/README.md`.

## Reproducibility

Before citing this repository as fully reproducible:

1. verify the exact PV01 Swin-UNet source used to create the released checkpoint;
2. verify the final fixed dataset manifest and split counts;
3. verify the final router experiment;
4. verify the confidence statistic used by the released pipeline;
5. run the repository from a clean clone;
6. archive a versioned release and record the release DOI/commit hash.

## Citation

See `CITATION.cff`.

## License

MIT License. See `LICENSE`.
